import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component{
  
  constructor(props){
    super(props);
    //this.state = {counter: 0} //initialize state
    this.increment = this.increment.bind(this);
  }
  
  state = {counter: 0} //initialize state
  
  //method
  increment(){
    this.setState({counter: this.state.counter + 1})
  }
  
render() {
    return (
	<div>
      <button onClick={this.increment}>Like</button>
      <p>{this.state.counter}</p>
	</div>
  );
}
}
export default App;
