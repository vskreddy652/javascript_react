import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
	render() {
		return (<div> <CTimer /><CTimer /><CTimer /></div>);
	}
}

class CTimer extends Component {
	//data...
	
	constructor(){
		super();
		
		//get current date/time and put it in state
		this.state = {dtm: (new Date()).toLocaleString()};
		
		this.startTimer();
	}

	//use SetInterval(), and in its body change the state after every timeout
	startTimer(){
		setInterval(
			()=>{ this.setState({dtm: (new Date()).toLocaleString()}); }
			, 1000);
	}

	/*	//methods...
	  handleClick=()=>{
		  this.setState({x:++x});
    //alert("Handleddddddddddd CLick event");
  };*/
  
  render() {
	  
	  var stl = {
		  display: 'inline'
	  };
	  
    return (
		<div style={stl}>
		{this.state.dtm }
		</div>
    );
  }
}

/*
class Comp1 extends Component {
	render(){
		return (
		<div>This is Component1
		{this.props.c1Prop}
		<Comp2 />
		</div>
	);
	}
}

class Comp2 extends Component {
	render(){
		return (
		<div>This is Component2</div>
	);
	}
}

App.defaultProps = {
	prop1:'wwwwwwww',
	prop2:'hhhhhhhh',
	prop3: 15,
}
*/


export default App;





