let map = new Map();

map.set('foo', 123);
console.log(map.get('foo'))


map.has('foo')

map.delete('foo')

map.has('foo')
